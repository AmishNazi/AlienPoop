var j = document.createElement('script');
j.src = chrome.extension.getURL('resources/jquery.js');
var s = document.createElement('script');
s.src = chrome.extension.getURL('resources/stylereset.js');
s.setAttribute('data-wallpaper',  chrome.extension.getURL('resources/Wallpapers/bg.png'));
s.setAttribute('id', 'AlienPoop');

(document.head||document.documentElement).appendChild(j);
  j.onload = function() {
    (document.head||document.documentElement).appendChild(s);

  };
