$(document).ready(function () {
    $.expr[':'].textEquals = function (a, i, m) {
    return $(a).text().match('^' + m[3] + '$');
  };
  $bg = $('#AlienPoop').data('wallpaper');
  $('#vbulletin_css').remove();
  $('iframe').removeAttr('height');
  $('iframe').removeAttr('width');
  $('iframe').css('max-width', '100%');
  $('#vB_Editor_QR_textarea').removeAttr('cols');
  $('#vB_Editor_QR_textarea').removeAttr('rows');
  $('.posts').removeAttr('style');
  $('.bigusername').removeAttr('style');
  $('.bigusername').parent().css('font-size', '18px');
  $('tbody[id="qr_error_tbody"]').toggle();
  $('tbody[id="collapseobj_forumrules"]').toggle();
  $('div:textEquals("Quote:")').next().css('border', 'dashed');
  $('div:textEquals("Quote:")').next().css('border-width', '1.25px');
  $('div:textEquals("Quote:")').next().css('margin-bottom', '16px');
  $('td.alt2 img[src="http://forums.joerogan.net/images/icons/icon1.gif"]').parent().addClass('smhide');
  $('td[title^="Replies"]').next().addClass('smhide');
  $('td[title^="Replies"]').next().next().addClass('smhide');
  $("td:contains('Replies')").addClass('smhide');
  $("td:contains('Views')").addClass('smhide');
  $("span:contains('Rating')").addClass('smhide');
  $('img[title="Reply With Quote"]').replaceWith('<button class="fa fa-mail-reply"></button>');
  $('img[title="Multi-Quote This Message"]').addClass('fa');
  $('img[title="Quick reply to this message"]').replaceWith('<button class="fa fa-rocket"></button>');
  $('img[title="Edit/Delete Message"]').replaceWith('<button class="fa fa-pencil-square-o"></button>');
  $('tbody#qr_error_tbody').detach();
  $(".thead:contains('PM')").wrapInner("<div class=date></div>");
  $(".thead:contains('AM')").wrapInner("<div class=date></div>");
  $('map[name="vb_headmap"]').remove();
  $('pre.alt2').attr('style');
  $('pre.alt2').removeAttr('style').toggleClass('alt2');
  $('body').fadeIn(0);
  $('body').css('display', 'block');
  $('html').css('background-image', "url("+$bg+")")
});
